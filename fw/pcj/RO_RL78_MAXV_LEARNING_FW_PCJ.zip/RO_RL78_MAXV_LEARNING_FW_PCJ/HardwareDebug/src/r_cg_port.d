src/r_cg_port.obj src/r_cg_port.d: ../src/r_cg_port.c
src/r_cg_port.obj src/r_cg_port.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_port.obj src/r_cg_port.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_PCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_PCJ\generate\iodefine.h:
src/r_cg_port.obj src/r_cg_port.d: ../src/r_cg_port.h
../src/r_cg_port.h:
src/r_cg_port.obj src/r_cg_port.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
