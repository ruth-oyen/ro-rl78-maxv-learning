src/r_cg_cgc.obj src/r_cg_cgc.d: ../src/r_cg_cgc.c
src/r_cg_cgc.obj src/r_cg_cgc.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_cgc.obj src/r_cg_cgc.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_PCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_PCJ\generate\iodefine.h:
src/r_cg_cgc.obj src/r_cg_cgc.d: ../src/r_cg_cgc.h
../src/r_cg_cgc.h:
src/r_cg_cgc.obj src/r_cg_cgc.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
