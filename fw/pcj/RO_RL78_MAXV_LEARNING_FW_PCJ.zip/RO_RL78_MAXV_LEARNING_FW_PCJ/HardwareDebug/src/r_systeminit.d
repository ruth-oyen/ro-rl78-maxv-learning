src/r_systeminit.obj src/r_systeminit.d: ../src/r_systeminit.c
src/r_systeminit.obj src/r_systeminit.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_systeminit.obj src/r_systeminit.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_PCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_PCJ\generate\iodefine.h:
src/r_systeminit.obj src/r_systeminit.d: ../src/r_cg_cgc.h
../src/r_cg_cgc.h:
src/r_systeminit.obj src/r_systeminit.d: ../src/r_cg_port.h
../src/r_cg_port.h:
src/r_systeminit.obj src/r_systeminit.d: ../src/r_cg_serial.h
../src/r_cg_serial.h:
src/r_systeminit.obj src/r_systeminit.d: ../src/r_cg_timer.h
../src/r_cg_timer.h:
src/r_systeminit.obj src/r_systeminit.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
