src/r_cg_serial.obj src/r_cg_serial.d: ../src/r_cg_serial.c
src/r_cg_serial.obj src/r_cg_serial.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_serial.obj src/r_cg_serial.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
src/r_cg_serial.obj src/r_cg_serial.d: ../src/r_cg_serial.h
../src/r_cg_serial.h:
src/r_cg_serial.obj src/r_cg_serial.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
