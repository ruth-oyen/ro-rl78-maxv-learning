src/r_cg_port_user.obj src/r_cg_port_user.d: ../src/r_cg_port_user.c
src/r_cg_port_user.obj src/r_cg_port_user.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_port_user.obj src/r_cg_port_user.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
src/r_cg_port_user.obj src/r_cg_port_user.d: ../src/r_cg_port.h
../src/r_cg_port.h:
src/r_cg_port_user.obj src/r_cg_port_user.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
