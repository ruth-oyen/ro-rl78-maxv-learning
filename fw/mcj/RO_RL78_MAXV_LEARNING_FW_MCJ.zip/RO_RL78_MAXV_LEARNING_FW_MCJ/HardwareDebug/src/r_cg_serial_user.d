src/r_cg_serial_user.obj src/r_cg_serial_user.d: ../src/r_cg_serial_user.c
src/r_cg_serial_user.obj src/r_cg_serial_user.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_serial_user.obj src/r_cg_serial_user.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
src/r_cg_serial_user.obj src/r_cg_serial_user.d: ../src/r_cg_serial.h
../src/r_cg_serial.h:
src/r_cg_serial_user.obj src/r_cg_serial_user.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
