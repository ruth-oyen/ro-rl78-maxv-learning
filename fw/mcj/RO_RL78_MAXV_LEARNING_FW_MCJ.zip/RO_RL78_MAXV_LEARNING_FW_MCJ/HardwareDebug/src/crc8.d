src/crc8.obj src/crc8.d: ../src/crc8.c
src/crc8.obj src/crc8.d: ../src/crc8.h
../src/crc8.h:
src/crc8.obj src/crc8.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/crc8.obj src/crc8.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
