src/tap_state_machine.obj src/tap_state_machine.d: ../src/tap_state_machine.c
src/tap_state_machine.obj src/tap_state_machine.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/tap_state_machine.obj src/tap_state_machine.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
src/tap_state_machine.obj src/tap_state_machine.d: ../src/tap_state_machine.h
../src/tap_state_machine.h:
