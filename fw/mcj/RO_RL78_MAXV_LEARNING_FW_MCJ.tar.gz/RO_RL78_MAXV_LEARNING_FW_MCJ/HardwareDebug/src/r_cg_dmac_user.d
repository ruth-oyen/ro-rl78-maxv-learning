src/r_cg_dmac_user.obj src/r_cg_dmac_user.d: ../src/r_cg_dmac_user.c
src/r_cg_dmac_user.obj src/r_cg_dmac_user.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_dmac_user.obj src/r_cg_dmac_user.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
src/r_cg_dmac_user.obj src/r_cg_dmac_user.d: ../src/r_cg_dmac.h
../src/r_cg_dmac.h:
src/r_cg_dmac_user.obj src/r_cg_dmac_user.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
