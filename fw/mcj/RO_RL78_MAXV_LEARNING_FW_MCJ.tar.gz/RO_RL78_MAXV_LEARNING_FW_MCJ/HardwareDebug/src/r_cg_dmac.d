src/r_cg_dmac.obj src/r_cg_dmac.d: ../src/r_cg_dmac.c
src/r_cg_dmac.obj src/r_cg_dmac.d: ../src/r_cg_macrodriver.h
../src/r_cg_macrodriver.h:
src/r_cg_dmac.obj src/r_cg_dmac.d: C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h
C:\work\6_e2studio\RO_RL78_MAXV_LEARNING_FW_MCJ\generate\iodefine.h:
src/r_cg_dmac.obj src/r_cg_dmac.d: ../src/r_cg_dmac.h
../src/r_cg_dmac.h:
src/r_cg_dmac.obj src/r_cg_dmac.d: ../src/r_cg_userdefine.h
../src/r_cg_userdefine.h:
