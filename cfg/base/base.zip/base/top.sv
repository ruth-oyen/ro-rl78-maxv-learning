module top
(
	output	logic	LED3,
	output	logic	LED2,
	output	logic	LED1,
	output	logic	LED0,
	output	logic	LED4,
	//		logic	VCCIO,
	input	logic	IO07_CLK0,
	//		logic	VCCINT,
	input	logic	IO09_CLK1,
	output	logic	LED5,
	output	logic	LED6,
	output	logic	LED7,
	input	logic	TOOL0,
	//		logic	TMS,
	//		logic	TDI,
	//		logic	TCK,
	//		logic	TDO,
	output	logic	EXTCLK,
	output	logic	INTP0,
	input	logic	P125, // Beaware, this pin is RESETn.
	input	logic	P41,
	input	logic	P42,
	//		logic	VCCIO,
	output	logic	GPIO21,
	output	logic	GPIO26,
	output	logic	GPIO20,
	output	logic	GPIO16,
	output	logic	DEV_OE,
	output	logic	DEV_CLRn,
	output	logic	GPIO19,
	output	logic	GPIO13,
	output	logic	GPIO6,
	output	logic	GPIO12,
	output	logic	GPIO5,
	output	logic	GPIO0,
	output	logic	GPIO1,
	output	logic	GPIO7,
	output	logic	GPIO11,
	//		logic	VCCIO,
	output	logic	GPIO9,
	//		logic	VCCIO,
	output	logic	GPIO10,
	input	logic	SW1,
	output	logic	RPIDCT,
	input	logic	SW2,
	output	logic	GPIO8,
	output	logic	GPIO25,
	output	logic	GPIO24,
	output	logic	GPIO22,
	output	logic	GPIO23,
	input	logic	U3RTX_Rn,
	output	logic	GPIO27,
	output	logic	GPIO17,
	output	logic	GPIO18,
	output	logic	GPIO15,
	input	logic	U3CTS_Rn,
	//		logic	VCCIO,
	input	logic	U3TXD_R,
	output	logic	GPIO14,
	output	logic	GPIO4,
	output	logic	GPIO3,
	output	logic	BEEP,
	output	logic	GPIO2,
	input	logic	U3RXD_R
);
	assign	LED0	= SW1;
	assign	LED1	= SW2;
	assign	LED2	= TOOL0;
	assign	LED3	= P41 | P42;
	assign	LED4	= P125;
	assign	LED5	= U3RTX_Rn  | U3CTS_Rn;
	assign	LED6	= U3TXD_R	| U3RXD_R;
	assign	LED7	= IO07_CLK0 | IO09_CLK1;

	assign	EXTCLK	= 1'b0;
	assign	INTP0	= 1'b0;
	assign	DEV_OE	= 1'b0;
	assign	DEV_CLRn= 1'b0;
	assign	RPIDCT	= 1'b0;

	assign	BEEP	= 1'b0;

	assign	GPIO2	= 1'b0;
	assign	GPIO3	= 1'b0;
	assign	GPIO4	= 1'b0;

	assign	GPIO14	= 1'b0;
	assign	GPIO15	= 1'b0;
	assign	GPIO18	= 1'b0;

	assign	GPIO17	= 1'b0;
	assign	GPIO27	= 1'b0;
	assign	GPIO22	= 1'b0;

	assign	GPIO23	= 1'b0;
	assign	GPIO24	= 1'b0;

	assign	GPIO10	= 1'b0;
	assign	GPIO9	= 1'b0;
	assign	GPIO11	= 1'b0;

	assign	GPIO25	= 1'b0;
	assign	GPIO8	= 1'b0;
	assign	GPIO7	= 1'b0;
	assign	GPIO1	= 1'b0;

	assign	GPIO0	= 1'b0;
	assign	GPIO5	= 1'b0;
	assign	GPIO6	= 1'b0;

	assign	GPIO12	= 1'b0;

	assign	GPIO13	= 1'b0;
	assign	GPIO19	= 1'b0;
	assign	GPIO26	= 1'b0;

	assign	GPIO16	= 1'b0;
	assign	GPIO20	= 1'b0;
	assign	GPIO21	= 1'b0;

	wire ufm_busy;
	wire ufm_osc;
	wire ufm_drdout;
	wire ufm_rtpbusy;

	(* noprune *) altufm_none #(
	    .intended_device_family ("MAX V"),
	    .lpm_file               ("ufm_increment.mif"),
	    .width_ufm_address      (9)
	) ufm0 (
	    .arclk    (1'b0),
	    .ardin    (1'b0),
	    .arshft   (1'b0),
	    .busy     (ufm_busy),

	    .drclk    (1'b0),
	    .drdin    (1'b0),
	    .drdout   (ufm_drdout),
	    .drshft   (1'b0),

	    .erase    (1'b0),
	    .osc      (ufm_osc),
	    .oscena   (1'b0),
	    .\program (1'b0),
	    .rtpbusy  (ufm_rtpbusy)
);

endmodule
