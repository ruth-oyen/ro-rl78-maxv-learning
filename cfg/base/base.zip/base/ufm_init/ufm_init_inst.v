	ufm_init u0 (
		.addr       (<connected-to-addr>),       //       addr.addr
		.nread      (<connected-to-nread>),      //      nread.nread
		.dataout    (<connected-to-dataout>),    //    dataout.dataout
		.nbusy      (<connected-to-nbusy>),      //      nbusy.nbusy
		.data_valid (<connected-to-data_valid>), // data_valid.data_valid
		.osc        (<connected-to-osc>)         //        osc.osc
	);

