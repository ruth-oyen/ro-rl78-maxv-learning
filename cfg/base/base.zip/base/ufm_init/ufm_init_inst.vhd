	component ufm_init is
		port (
			addr       : in  std_logic_vector(8 downto 0)  := (others => 'X'); -- addr
			nread      : in  std_logic                     := 'X';             -- nread
			dataout    : out std_logic_vector(15 downto 0);                    -- dataout
			nbusy      : out std_logic;                                        -- nbusy
			data_valid : out std_logic;                                        -- data_valid
			osc        : out std_logic                                         -- osc
		);
	end component ufm_init;

	u0 : component ufm_init
		port map (
			addr       => CONNECTED_TO_addr,       --       addr.addr
			nread      => CONNECTED_TO_nread,      --      nread.nread
			dataout    => CONNECTED_TO_dataout,    --    dataout.dataout
			nbusy      => CONNECTED_TO_nbusy,      --      nbusy.nbusy
			data_valid => CONNECTED_TO_data_valid, -- data_valid.data_valid
			osc        => CONNECTED_TO_osc         --        osc.osc
		);

