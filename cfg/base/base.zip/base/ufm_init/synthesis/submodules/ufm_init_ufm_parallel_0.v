//altufm_parallel ACCESS_MODE="READ_ONLY" CBX_AUTO_BLACKBOX="ALL" CBX_SINGLE_OUTPUT_FILE="ON" DEVICE_FAMILY="MAX V" ERASE_TIME=500000000 LPM_FILE="C:/work/7_quartus_prime/base/ufm_increment.mif" OSC_FREQUENCY=180000 PROGRAM_TIME=1600000 WIDTH_ADDRESS=9 WIDTH_DATA=16 WIDTH_UFM_ADDRESS=9 addr data_valid dataout nbusy nread osc
//VERSION_BEGIN 25.1 cbx_a_gray2bin 2025:10:22:10:31:27:SC cbx_a_graycounter 2025:10:22:10:31:27:SC cbx_altufm_parallel 2025:10:22:10:31:27:SC cbx_cycloneii 2025:10:22:10:31:27:SC cbx_lpm_add_sub 2025:10:22:10:31:27:SC cbx_lpm_compare 2025:10:22:10:31:27:SC cbx_lpm_counter 2025:10:22:10:31:27:SC cbx_lpm_decode 2025:10:22:10:31:27:SC cbx_lpm_mux 2025:10:22:10:31:26:SC cbx_maxii 2025:10:22:10:31:27:SC cbx_mgl 2025:10:22:10:31:44:SC cbx_nadder 2025:10:22:10:31:27:SC cbx_stratix 2025:10:22:10:31:27:SC cbx_stratixii 2025:10:22:10:31:26:SC cbx_util_mgl 2025:10:22:10:31:27:SC  VERSION_END
// synthesis VERILOG_INPUT_VERSION VERILOG_2001
// altera message_off 10463



// Copyright (C) 2025  Altera Corporation. All rights reserved.
//  Your use of Altera Corporation's design tools, logic functions 
//  and other software and tools, and any partner logic 
//  functions, and any output files from any of the foregoing 
//  (including device programming or simulation files), and any 
//  associated documentation or information are expressly subject 
//  to the terms and conditions of the Altera Program License 
//  Subscription Agreement, the Altera Quartus Prime License Agreement,
//  the Altera IP License Agreement, or other applicable license
//  agreement, including, without limitation, that your use is for
//  the sole purpose of programming logic devices manufactured by
//  Altera and sold by Altera or its authorized distributors.  Please
//  refer to the Altera Software License Subscription Agreements 
//  on the Quartus Prime software download page.



//synthesis_resources = lpm_counter 1 lut 62 maxv_ufm 1 
//synopsys translate_off
`timescale 1 ps / 1 ps
//synopsys translate_on
(* ALTERA_ATTRIBUTE = {"suppress_da_rule_internal=c101;suppress_da_rule_internal=c103;suppress_da_rule_internal=c104;suppress_da_rule_internal=r101;suppress_da_rule_internal=s104;suppress_da_rule_internal=s102"} *)
module  ufm_init_ufm_parallel_0
	( 
	addr,
	data_valid,
	dataout,
	nbusy,
	nread,
	osc) /* synthesis synthesis_clearbox=1 */;
	input   [8:0]  addr;
	output   data_valid;
	output   [15:0]  dataout;
	output   nbusy;
	input   nread;
	output   osc;

	reg	[8:0]	A;
	reg	data_valid_out_reg;
	reg	data_valid_reg;
	reg	deco1_dffe;
	reg	decode_dffe;
	reg	gated_clk1_dffe;
	reg	gated_clk2_dffe;
	reg	real_decode2_dffe;
	reg	real_decode_dffe;
	reg	[15:0]	sipo_dffe;
	wire	[15:0]	wire_tmp_do_d;
	reg	[15:0]	tmp_do;
	wire	[15:0]	wire_tmp_do_ena;
	wire  [4:0]   wire_cntr2_q;
	wire  wire_maxii_ufm_block1_bgpbusy;
	wire  wire_maxii_ufm_block1_drdout;
	wire  wire_maxii_ufm_block1_osc;
	wire  add_en;
	wire  add_load;
	wire  arclk;
	wire  busy_arclk;
	wire  busy_drclk;
	wire  control_mux;
	wire  copy_tmp_decode;
	wire  data_valid_en;
	wire  dly_tmp_decode;
	wire  drdin;
	wire  gated1;
	wire  gated2;
	wire  hold_decode;
	wire  in_read_data_en;
	wire  in_read_drclk;
	wire  in_read_drshft;
	wire  mux_nread;
	wire oscena;
	wire  q0;
	wire  q1;
	wire  q2;
	wire  q3;
	wire  q4;
	wire  read;
	wire  read_op;
	wire  real_decode;
	wire  [8:0]  shiftin;
	wire  [15:0]  sipo_q;
	wire  start_decode;
	wire  start_op;
	wire  stop_op;
	wire  tmp_add_en;
	wire  tmp_add_load;
	wire  tmp_arclk;
	wire  tmp_arclk0;
	wire  tmp_ardin;
	wire  tmp_arshft;
	wire  tmp_data_valid2;
	wire  tmp_decode;
	wire  tmp_drclk;
	wire  tmp_in_read_data_en;
	wire  tmp_in_read_drclk;
	wire  tmp_in_read_drshft;
	wire  tmp_read;
	wire  ufm_arclk;
	wire  ufm_ardin;
	wire  ufm_arshft;
	wire  ufm_bgpbusy;
	wire  ufm_drclk;
	wire  ufm_drdin;
	wire  ufm_drdout;
	wire  ufm_drshft;
	wire  ufm_osc;
	wire  ufm_oscena;
	wire  [8:0]  X_var;
	wire  [8:0]  Y_var;
	wire  [8:0]  Z_var;

	// synopsys translate_off
	initial
		A = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (add_en == 1'b1)   A <= {Z_var};
	// synopsys translate_off
	initial
		data_valid_out_reg = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		  data_valid_out_reg <= (data_valid_reg & (~ tmp_decode));
	// synopsys translate_off
	initial
		data_valid_reg = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (data_valid_en == 1'b1)   data_valid_reg <= tmp_data_valid2;
	// synopsys translate_off
	initial
		deco1_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (start_op == 1'b1)   deco1_dffe <= mux_nread;
	// synopsys translate_off
	initial
		decode_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		  decode_dffe <= copy_tmp_decode;
	// synopsys translate_off
	initial
		gated_clk1_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		  gated_clk1_dffe <= busy_arclk;
	// synopsys translate_off
	initial
		gated_clk2_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		  gated_clk2_dffe <= busy_drclk;
	// synopsys translate_off
	initial
		real_decode2_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		  real_decode2_dffe <= real_decode_dffe;
	// synopsys translate_off
	initial
		real_decode_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		  real_decode_dffe <= start_decode;
	// synopsys translate_off
	initial
		sipo_dffe = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (in_read_data_en == 1'b1)   sipo_dffe <= {sipo_q[14:0], ufm_drdout};
	// synopsys translate_off
	initial
		tmp_do[0:0] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[0:0] == 1'b1)   tmp_do[0:0] <= wire_tmp_do_d[0:0];
	// synopsys translate_off
	initial
		tmp_do[1:1] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[1:1] == 1'b1)   tmp_do[1:1] <= wire_tmp_do_d[1:1];
	// synopsys translate_off
	initial
		tmp_do[2:2] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[2:2] == 1'b1)   tmp_do[2:2] <= wire_tmp_do_d[2:2];
	// synopsys translate_off
	initial
		tmp_do[3:3] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[3:3] == 1'b1)   tmp_do[3:3] <= wire_tmp_do_d[3:3];
	// synopsys translate_off
	initial
		tmp_do[4:4] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[4:4] == 1'b1)   tmp_do[4:4] <= wire_tmp_do_d[4:4];
	// synopsys translate_off
	initial
		tmp_do[5:5] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[5:5] == 1'b1)   tmp_do[5:5] <= wire_tmp_do_d[5:5];
	// synopsys translate_off
	initial
		tmp_do[6:6] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[6:6] == 1'b1)   tmp_do[6:6] <= wire_tmp_do_d[6:6];
	// synopsys translate_off
	initial
		tmp_do[7:7] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[7:7] == 1'b1)   tmp_do[7:7] <= wire_tmp_do_d[7:7];
	// synopsys translate_off
	initial
		tmp_do[8:8] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[8:8] == 1'b1)   tmp_do[8:8] <= wire_tmp_do_d[8:8];
	// synopsys translate_off
	initial
		tmp_do[9:9] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[9:9] == 1'b1)   tmp_do[9:9] <= wire_tmp_do_d[9:9];
	// synopsys translate_off
	initial
		tmp_do[10:10] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[10:10] == 1'b1)   tmp_do[10:10] <= wire_tmp_do_d[10:10];
	// synopsys translate_off
	initial
		tmp_do[11:11] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[11:11] == 1'b1)   tmp_do[11:11] <= wire_tmp_do_d[11:11];
	// synopsys translate_off
	initial
		tmp_do[12:12] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[12:12] == 1'b1)   tmp_do[12:12] <= wire_tmp_do_d[12:12];
	// synopsys translate_off
	initial
		tmp_do[13:13] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[13:13] == 1'b1)   tmp_do[13:13] <= wire_tmp_do_d[13:13];
	// synopsys translate_off
	initial
		tmp_do[14:14] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[14:14] == 1'b1)   tmp_do[14:14] <= wire_tmp_do_d[14:14];
	// synopsys translate_off
	initial
		tmp_do[15:15] = 0;
	// synopsys translate_on
	always @ ( posedge ufm_osc)
		if (wire_tmp_do_ena[15:15] == 1'b1)   tmp_do[15:15] <= wire_tmp_do_d[15:15];
	assign
		wire_tmp_do_d = {sipo_q[15:0]};
	assign
		wire_tmp_do_ena = {16{(data_valid_reg & (~ tmp_decode))}};
	lpm_counter   cntr2
	( 
	.clk_en(tmp_decode),
	.clock(ufm_osc),
	.cout(),
	.eq(),
	.q(wire_cntr2_q)
	`ifndef FORMAL_VERIFICATION
	// synopsys translate_off
	`endif
	,
	.aclr(1'b0),
	.aload(1'b0),
	.aset(1'b0),
	.cin(1'b1),
	.cnt_en(1'b1),
	.data({5{1'b0}}),
	.sclr(1'b0),
	.sload(1'b0),
	.sset(1'b0),
	.updown(1'b1)
	`ifndef FORMAL_VERIFICATION
	// synopsys translate_on
	`endif
	);
	defparam
		cntr2.lpm_direction = "UP",
		cntr2.lpm_modulus = 28,
		cntr2.lpm_port_updown = "PORT_UNUSED",
		cntr2.lpm_width = 5,
		cntr2.lpm_type = "lpm_counter";
	maxv_ufm   maxii_ufm_block1
	( 
	.arclk(ufm_arclk),
	.ardin(ufm_ardin),
	.arshft(ufm_arshft),
	.bgpbusy(wire_maxii_ufm_block1_bgpbusy),
	.busy(),
	.drclk(ufm_drclk),
	.drdin(ufm_drdin),
	.drdout(wire_maxii_ufm_block1_drdout),
	.drshft(ufm_drshft),
	.osc(wire_maxii_ufm_block1_osc),
	.oscena(ufm_oscena)
	`ifndef FORMAL_VERIFICATION
	// synopsys translate_off
	`endif
	,
	.erase(1'b0),
	.program(1'b0)
	`ifndef FORMAL_VERIFICATION
	// synopsys translate_on
	`endif
	// synopsys translate_off
	,
	.ctrl_bgpbusy(1'b0),
	.devclrn(1'b1),
	.devpor(1'b1),
	.sbdin(1'b0),
	.sbdout()
	// synopsys translate_on
	);
	defparam
		maxii_ufm_block1.address_width = 9,
		maxii_ufm_block1.erase_time = 500000000,
		maxii_ufm_block1.init_file = "C:/work/7_quartus_prime/base/ufm_increment.mif",
		maxii_ufm_block1.mem1 = 512'h001F001E001D001C001B001A0019001800170016001500140013001200110010000F000E000D000C000B000A0009000800070006000500040003000200010000,
		maxii_ufm_block1.mem10 = 512'h013F013E013D013C013B013A0139013801370136013501340133013201310130012F012E012D012C012B012A0129012801270126012501240123012201210120,
		maxii_ufm_block1.mem11 = 512'h015F015E015D015C015B015A0159015801570156015501540153015201510150014F014E014D014C014B014A0149014801470146014501440143014201410140,
		maxii_ufm_block1.mem12 = 512'h017F017E017D017C017B017A0179017801770176017501740173017201710170016F016E016D016C016B016A0169016801670166016501640163016201610160,
		maxii_ufm_block1.mem13 = 512'h019F019E019D019C019B019A0199019801970196019501940193019201910190018F018E018D018C018B018A0189018801870186018501840183018201810180,
		maxii_ufm_block1.mem14 = 512'h01BF01BE01BD01BC01BB01BA01B901B801B701B601B501B401B301B201B101B001AF01AE01AD01AC01AB01AA01A901A801A701A601A501A401A301A201A101A0,
		maxii_ufm_block1.mem15 = 512'h01DF01DE01DD01DC01DB01DA01D901D801D701D601D501D401D301D201D101D001CF01CE01CD01CC01CB01CA01C901C801C701C601C501C401C301C201C101C0,
		maxii_ufm_block1.mem16 = 512'h01FF01FE01FD01FC01FB01FA01F901F801F701F601F501F401F301F201F101F001EF01EE01ED01EC01EB01EA01E901E801E701E601E501E401E301E201E101E0,
		maxii_ufm_block1.mem2 = 512'h003F003E003D003C003B003A0039003800370036003500340033003200310030002F002E002D002C002B002A0029002800270026002500240023002200210020,
		maxii_ufm_block1.mem3 = 512'h005F005E005D005C005B005A0059005800570056005500540053005200510050004F004E004D004C004B004A0049004800470046004500440043004200410040,
		maxii_ufm_block1.mem4 = 512'h007F007E007D007C007B007A0079007800770076007500740073007200710070006F006E006D006C006B006A0069006800670066006500640063006200610060,
		maxii_ufm_block1.mem5 = 512'h009F009E009D009C009B009A0099009800970096009500940093009200910090008F008E008D008C008B008A0089008800870086008500840083008200810080,
		maxii_ufm_block1.mem6 = 512'h00BF00BE00BD00BC00BB00BA00B900B800B700B600B500B400B300B200B100B000AF00AE00AD00AC00AB00AA00A900A800A700A600A500A400A300A200A100A0,
		maxii_ufm_block1.mem7 = 512'h00DF00DE00DD00DC00DB00DA00D900D800D700D600D500D400D300D200D100D000CF00CE00CD00CC00CB00CA00C900C800C700C600C500C400C300C200C100C0,
		maxii_ufm_block1.mem8 = 512'h00FF00FE00FD00FC00FB00FA00F900F800F700F600F500F400F300F200F100F000EF00EE00ED00EC00EB00EA00E900E800E700E600E500E400E300E200E100E0,
		maxii_ufm_block1.mem9 = 512'h011F011E011D011C011B011A0119011801170116011501140113011201110110010F010E010D010C010B010A0109010801070106010501040103010201010100,
		maxii_ufm_block1.osc_sim_setting = 180000,
		maxii_ufm_block1.program_time = 1600000,
		maxii_ufm_block1.lpm_type = "maxv_ufm";
	assign
		add_en = (tmp_add_en & read_op),
		add_load = (tmp_add_load & read_op),
		arclk = (tmp_arclk0 & read_op),
		busy_arclk = arclk,
		busy_drclk = in_read_drclk,
		control_mux = (((~ q4) & ((q3 | q2) | q1)) | q4),
		copy_tmp_decode = tmp_decode,
		data_valid = data_valid_out_reg,
		data_valid_en = ((q4 & q3) & q1),
		dataout = tmp_do,
		dly_tmp_decode = decode_dffe,
		drdin = 1'b0,
		gated1 = gated_clk1_dffe,
		gated2 = gated_clk2_dffe,
		hold_decode = ((~ real_decode2_dffe) & real_decode),
		in_read_data_en = (tmp_in_read_data_en & read_op),
		in_read_drclk = (tmp_in_read_drclk & read_op),
		in_read_drshft = (tmp_in_read_drshft & read_op),
		mux_nread = (((~ control_mux) & read) | (control_mux & (~ data_valid_en))),
		nbusy = ((~ dly_tmp_decode) & (~ ufm_bgpbusy)),
		osc = ufm_osc,
		oscena = 1'b1,
		q0 = wire_cntr2_q[0],
		q1 = wire_cntr2_q[1],
		q2 = wire_cntr2_q[2],
		q3 = wire_cntr2_q[3],
		q4 = wire_cntr2_q[4],
		read = (~ nread),
		read_op = tmp_read,
		real_decode = start_decode,
		shiftin = {A[7:0], 1'b0},
		sipo_q = {sipo_dffe[15:0]},
		start_decode = (mux_nread & (~ ufm_bgpbusy)),
		start_op = (hold_decode | stop_op),
		stop_op = ((((q4 & q3) & (~ q2)) & q1) & q0),
		tmp_add_en = ((~ q4) & ((~ q3) | ((~ q2) & (~ q1)))),
		tmp_add_load = (~ ((~ q4) & (((((~ q3) & q2) | ((~ q3) & q0)) | ((~ q3) & q1)) | ((q3 & (~ q2)) & (~ q1))))),
		tmp_arclk = (gated1 & (~ ufm_osc)),
		tmp_arclk0 = ((~ q4) & ((~ q3) | (((~ q2) & (~ q1)) & (~ q0)))),
		tmp_ardin = A[8],
		tmp_arshft = add_en,
		tmp_data_valid2 = (stop_op & read_op),
		tmp_decode = tmp_read,
		tmp_drclk = (gated2 & (~ ufm_osc)),
		tmp_in_read_data_en = (((~ q4) & ((q3 & q2) | (q3 & q1))) | (q4 & (((~ q3) | ((~ q2) & (~ q1))) | (q1 & (~ q0))))),
		tmp_in_read_drclk = (((~ q4) & ((q3 & q2) | (q3 & q1))) | (q4 & (((~ q3) | ((~ q2) & (~ q1))) | (q1 & (~ q0))))),
		tmp_in_read_drshft = (~ (((((~ q4) & q3) & (~ q2)) & q1) & q0)),
		tmp_read = deco1_dffe,
		ufm_arclk = tmp_arclk,
		ufm_ardin = tmp_ardin,
		ufm_arshft = tmp_arshft,
		ufm_bgpbusy = wire_maxii_ufm_block1_bgpbusy,
		ufm_drclk = tmp_drclk,
		ufm_drdin = drdin,
		ufm_drdout = wire_maxii_ufm_block1_drdout,
		ufm_drshft = in_read_drshft,
		ufm_osc = wire_maxii_ufm_block1_osc,
		ufm_oscena = oscena,
		X_var = (shiftin & {9{(~ add_load)}}),
		Y_var = (addr & {9{add_load}}),
		Z_var = (X_var | Y_var);
endmodule //ufm_init_ufm_parallel_0
//VALID FILE
