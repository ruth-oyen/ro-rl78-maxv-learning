
module ufm_init (
	addr,
	nread,
	dataout,
	nbusy,
	data_valid,
	osc);	

	input	[8:0]	addr;
	input		nread;
	output	[15:0]	dataout;
	output		nbusy;
	output		data_valid;
	output		osc;
endmodule
